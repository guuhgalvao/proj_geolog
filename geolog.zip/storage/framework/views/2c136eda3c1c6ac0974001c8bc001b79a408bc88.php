<?php if(count($users) > 0): ?>
    <div class="card border-info mt-4" id="card_ResultList">
        <div class="card-header bg-info text-white"><?php echo app('translator')->getFromJson('Users List'); ?></div>
        <div class="table-responsive" id="tb_ResultList">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->getFromJson('Name'); ?></th>
                        <th><?php echo app('translator')->getFromJson('E-mail'); ?></th>
                        <th><?php echo app('translator')->getFromJson('CPF'); ?></th>
                        <th><?php echo app('translator')->getFromJson('Sector'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-id="<?php echo e($user->id); ?>">
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->cpf); ?></td>
                            <td><?php echo e($user->sector->name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="col-12">
                <div class="row justify-content-center">
                        <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-info alert-dismissible fade show mt-3" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        Não há resultados
    </div>
<?php endif; ?>
