<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border-success mt-2" id="card_ResultList">
                <div class="card-header bg-success text-white"><?php echo app('translator')->getFromJson('Researches List'); ?></div>
                <div class="table-responsive" id="tb_ResultList">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->getFromJson('Sector'); ?></th>
                                <th><?php echo app('translator')->getFromJson('Question Name'); ?></th>
                                <th><?php echo app('translator')->getFromJson('Questions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $researches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($research->id); ?>">
                                    <td><?php echo e($research->sector->name); ?></td>
                                    <td><?php echo e($research->name); ?></td>
                                    <td><?php echo e(count($research->questions)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        jQuery(document).ready(function($){
            $(document).on('click', '#tb_ResultList tbody tr', function(e){
                window.location.href = "<?php echo e(route('research')); ?>/"+$(this).data('id');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>