<?php if(count($sectors) > 0): ?>
    <div class="card border-info mt-4" id="card_ResultList">
        <div class="card-header bg-info text-white"><?php echo app('translator')->getFromJson('Sectors List'); ?></div>
        <div class="table-responsive" id="tb_ResultList">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->getFromJson('Name'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-id="<?php echo e($sector->id); ?>">
                            <td><?php echo e($sector->name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="col-12">
                <div class="row justify-content-center">
                        <?php echo e($sectors->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-info alert-dismissible fade show mt-3" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        Não há resultados
    </div>
<?php endif; ?>
