<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-success text-white"><?php echo app('translator')->getFromJson('Question Form'); ?></div>
                <div class="card-body">
                    <div class="col-md-12" id="alerts"></div>
                    <form class="col-12" method="POST" action="<?php echo e(route('research')); ?>" id="form_Questions">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="research_id" id="research_id" value="<?php echo e($research->id); ?>">
                        <input type="hidden" name="progress_id" id="progress_id" value="<?php echo e($progress->id); ?>">
                        <input type="hidden" name="question_id" id="question_id" value="<?php echo e($question->id); ?>">
                        <p><?php echo e($question->text); ?></p>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" id="answer<?php echo e($option->id); ?>" name="answer" class="custom-control-input" value="<?php echo e($option->value); ?>">
                                        <label class="custom-control-label" for="answer<?php echo e($option->id); ?>"><?php echo e($option->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <button type="button" class="btn btn-success" name="btn_Action" value="finish"><?php echo app('translator')->getFromJson('Finish'); ?></button>
                        <button type="button" class="btn btn-success" name="btn_Action" value="next"><?php echo app('translator')->getFromJson('Next'); ?></button>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        jQuery(document).ready(function($){
            function submitForm(actionType){
                showLoader(function(){
                    $('#form_Questions').ajaxSubmit({
                        data: {actionType: actionType},
                        dataType: 'json',
                        success: function(response){
                            if(!Boolean(response.error)){
                                // $('#alerts').append('<div class="alert alert-'+response.alerts['type']+' alert-dismissible fade show" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+response.alerts['text']+'</div>');
                                if(!$.isEmptyObject(response.redirect)){
                                    window.location.href = response.redirect;
                                }else{
                                    window.location.reload();
                                }
                            }else{
                                $('#alerts').append('<div class="alert alert-'+response.alerts['type']+' alert-dismissible fade show" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+response.alerts['text']+'</div>');
                            }
                            hideLoader();
                        }
                    });
                });
            }

            $('button[name=btn_Action]').on('click', function(){
                $('#alerts div.alert').remove();
                submitForm($(this).val());
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fullscreen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>